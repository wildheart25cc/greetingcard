package com.android.example.countdowntimer;

import android.app.Activity;
import android.content.res.Configuration;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.text.format.DateUtils;
import android.widget.ImageView;
import android.widget.TextView;
import java.util.Calendar;
import java.util.concurrent.TimeUnit;


public class MainActivity extends Activity {

    private CountDownTimer countDownTimer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ImageView iv = findViewById(R.id.world_cup_image_view);
        //iv.setImageResource(R.drawable.worldcup2018portrait1);

        //Create an Object of the Configuration class
        Configuration config = getResources().getConfiguration();

        //check the orientation of the device
        if (config.orientation == Configuration.ORIENTATION_PORTRAIT)
        {
            iv.setImageResource(R.drawable.worldcup2018portrait1);
        }

        else
        {
            iv.setImageResource(R.drawable.worldcup2018landscape1);
        }

        //Set the scaleType of the ImageView to FIT_XY
        iv.setScaleType(ImageView.ScaleType.FIT_XY);


        //Get the textView reference to the TextView in the application
        final TextView countDownText = findViewById(R.id.countdown_text);

        // Use the Java Calendar API to get the current time
        Calendar currentTime = Calendar.getInstance();

        Calendar dueDate = Calendar.getInstance();
        dueDate.set(2018, 6, 3, 22, 0, 0);

        // Calculate how many milliseconds are left between now and the dueDate.
        long nowInMillis = currentTime.getTimeInMillis();
        long endMillis = dueDate.getTimeInMillis();
        long millisUntilGame = endMillis - nowInMillis;

        /*
            Create an anonymous instance of the abstract CountdownTimer class with a tick period of 1 second (1000 milliseconds)
            that will finish on the dueDate.
        */
        // Hold a reference to the countdown timer so that we can stop it whenever we close the MainActivity.
        countDownTimer = new CountDownTimer(millisUntilGame, DateUtils.SECOND_IN_MILLIS)
        {
            @Override
            //The onTick() method gives how many milliseconds are left until the dueDate time
            public void onTick(long millisUntilFinished) {

                /*
                 Convert the remaining milliseconds into days and whatever is left from that, into hours (less than 24).
                 Repeat the same for minutes and seconds.
                 We decrement `millisUntilFinished` every time, so that we can keep the days less than one.
                 Same for hours - less than 24, minutes - less than 60 and seconds - less than 60.
                */
                long days = TimeUnit.MILLISECONDS.toDays(millisUntilFinished);
                millisUntilFinished -= TimeUnit.DAYS.toMillis(days);

                long hours = TimeUnit.MILLISECONDS.toHours(millisUntilFinished);
                millisUntilFinished -= TimeUnit.HOURS.toMillis(hours);

                long minutes = TimeUnit.MILLISECONDS.toMinutes(millisUntilFinished);
                millisUntilFinished -= TimeUnit.MINUTES.toMillis(minutes);

                long seconds = TimeUnit.MILLISECONDS.toSeconds(millisUntilFinished);

                String textToShow = String.format("%d days, %d hours, %d minutes, %d seconds left", days, hours, minutes, seconds);

                countDownText.setText(textToShow);
            }

            //what do i want the application to do as soon as the timer is finished
            @Override
            public void onFinish() {
                countDownText.setTypeface(null, Typeface.BOLD_ITALIC);
                countDownText.setText("Kick Off!");
            }
        };

        //start the timer
        countDownTimer.start();
    }
}
































